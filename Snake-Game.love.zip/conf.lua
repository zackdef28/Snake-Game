function love.conf(tbl)
  tbl.window.width = 500
  tbl.window.height = 500
  tbl.window.title = 'My Snake Game'
  tbl.window.console = true
end
